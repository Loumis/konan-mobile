// FI9_PATCH v14.0 - ChatGPT Mobile 2025 UI
// ChatScreen.jsx - Style ChatGPT Mobile 2025 complet
// Preserves ALL KONAN logic (hooks, callbacks, services, storage)

import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  ActivityIndicator,
  Alert,
  Platform,
  StyleSheet,
  View,
  FlatList,
  Text,
  TouchableOpacity,
  useWindowDimensions,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

import { useAppTheme } from "../context/AppThemeContext";
import { useLanguage } from "../context/LanguageContext";
import { useAuth } from "../hooks/useAuth";
import { chatColors } from "../constants/colors";

import { sendMessage } from "../services/ChatService";
import ChatSidebar from "../components/ChatSidebar";
import AnimatedMessageBubble from "../components/AnimatedMessageBubble";
import ChatTypingIndicator from "../components/ChatTypingIndicator";
import Composer from "../components/Composer";
import FI9_AttachmentsSheet from "../components/FI9_AttachmentsSheet";

// FI9_UI_UPGRADE v15.0 - New components with feature flags
import EnhancedSidebar from "../components/EnhancedSidebar";
import EnhancedMessageInput from "../components/EnhancedMessageInput";
import VoiceInput from "../components/VoiceInput";
import UserMenu from "../components/UserMenu";

// ============================================
// FEATURE FLAGS - UI V15 UPGRADE
// ============================================
// Set to false to revert to old components instantly
const UI_V15_SIDEBAR_ENABLED = true;
const UI_V15_INPUT_ENABLED = true;
const UI_V15_VOICE_ENABLED = false; // Disabled by default (requires STT backend)
const UI_V15_USERMENU_ENABLED = true;

import {
  getSessions,
  getMessages,
  saveMessages,
  saveCurrentSession,
  getCurrentSession,
  createNewSession,
} from "../utils/chatStorage";

export default function ChatScreen() {
  // ============================================
  // 1. CONTEXT HOOKS (toujours en premier, ordre fixe)
  // ============================================
  const { theme } = useAppTheme();
  const { language, t } = useLanguage();
  const { user, status, logout, token } = useAuth();
  const navigation = useNavigation();

  // FI9_PATCH v14.0: Hook de dimensions pour gérer la responsivité
  const { width } = useWindowDimensions();
  const isMobile = width < 720; // Mobile < 720px - utilisé uniquement pour le bouton menu

  // ============================================
  // 2. STATE HOOKS (tous les useState)
  // ============================================
  const [loading, setLoading] = useState(true);
  const [sessions, setSessions] = useState([]);
  const [currentSessionId, setCurrentSessionId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [sending, setSending] = useState(false);
  const [isSidebarVisible, setIsSidebarVisible] = useState(false);
  const [isAttachmentsSheetVisible, setIsAttachmentsSheetVisible] = useState(false);

  // ============================================
  // 3. REF HOOKS (tous les useRef)
  // ============================================
  const flatListRef = useRef(null);
  const scrollTimeoutRef = useRef(null);

  // ============================================
  // 4. MEMO HOOKS (useMemo)
  // ============================================
  const username = useMemo(
    () =>
      user?.name ||
      user?.full_name ||
      user?.username ||
      user?.email?.split("@")[0] ||
      user?.email ||
      "User",
    [user]
  );

  const planLabel = useMemo(() => {
    const planRaw = user?.plan || user?.subscription || "free";
    return planRaw?.toLowerCase() === "legal+"
      ? "Legal+"
      : planRaw?.toLowerCase() === "pro"
      ? "Pro"
      : "Free";
  }, [user]);

  // FI9_PATCH v14.0: Styles ChatGPT Mobile 2025
  const styles = useMemo(
    () =>
      StyleSheet.create({
        safe: {
          flex: 1,
          backgroundColor: theme.background || chatColors.background,
        },
        container: {
          flex: 1,
          flexDirection: "row",
          backgroundColor: theme.background || chatColors.background,
          width: "100%",
          height: "100%",
        },
        sidebarColumn: {
          width: 260,
          flexShrink: 0,
          borderRightWidth: 1,
          borderRightColor: theme.border || chatColors.border,
          backgroundColor: theme.background || chatColors.background,
        },
        mainColumn: {
          flex: 1,
          flexDirection: "column",
          backgroundColor: theme.background || chatColors.background || "#111",
          overflow: "hidden",
        },
        // FI9_PATCH v14.0: TopBar minimaliste style ChatGPT
        topBar: {
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          paddingHorizontal: 16,
          paddingVertical: 12,
          borderBottomWidth: 1,
          borderBottomColor: theme.border || chatColors.border,
          backgroundColor: theme.background || chatColors.background || "#181818",
        },
        topBarLeft: {
          flexDirection: "row",
          alignItems: "center",
          gap: 12,
        },
        topBarTitle: {
          fontSize: 18,
          fontWeight: "600",
          color: theme.text || chatColors.textPrimary,
        },
        topBarPlan: {
          fontSize: 14,
          fontWeight: "400",
          color: theme.textMuted || chatColors.textSecondary,
          marginLeft: 4,
        },
        mobileMenuButton: {
          padding: 4,
        },
        messagesContainer: {
          flex: 1,
        },
        messagesContent: {
          paddingTop: 12,
          paddingBottom: 12,
        },
        composerContainer: {
          backgroundColor: theme.background || chatColors.background,
          paddingBottom: 0, // FI9: KEYBOARD SAFE - Padding handled by parent View
          // NO zIndex - component is in normal flow
          // NO elevation - component is in normal flow
        },
        loadingContainer: {
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: theme.background || chatColors.background,
        },
        emptyContainer: {
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          paddingHorizontal: 24,
          maxWidth: 420,
          alignSelf: "center",
        },
        emptyText: {
          color: theme.text || chatColors.textPrimary,
          fontSize: 20,
          fontWeight: "700",
          marginBottom: 6,
          textAlign: "center",
        },
        emptySubtext: {
          color: theme.textMuted || chatColors.textSecondary,
          fontSize: 14,
          textAlign: "center",
        },
      }),
    [theme, width]
  );

  // ============================================
  // 5. EFFECT HOOKS (tous les useEffect)
  // ============================================
  // Cleanup scrollTimeoutRef
  useEffect(() => {
    return () => {
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
    };
  }, []);

  // Redirection si non authentifié
  useEffect(() => {
    if (status === "unauthenticated") {
      navigation.reset({
        index: 0,
        routes: [{ name: "Login" }],
      });
    }
  }, [status, navigation]);

  // Initialisation : dernière session + messages
  useEffect(() => {
    let isMounted = true;

    const initChat = async () => {
      try {
        // Charger toutes les sessions
        const loadedSessions = await getSessions();
        if (!isMounted) return;
        setSessions(loadedSessions);

        // Charger la session courante
        const lastSessionId = await getCurrentSession();
        let sessionIdToLoad = null;

        if (lastSessionId) {
          const session = loadedSessions.find((s) => s.id === lastSessionId);
          if (session) {
            sessionIdToLoad = lastSessionId;
          }
        } else if (loadedSessions.length > 0) {
          sessionIdToLoad = loadedSessions[0].id;
        }

        if (sessionIdToLoad) {
          const storedMessages = await getMessages(sessionIdToLoad);
          if (!isMounted) return;
          setCurrentSessionId(sessionIdToLoad);
          setMessages(storedMessages || []);
          await saveCurrentSession(sessionIdToLoad);
        } else {
          // Créer une nouvelle session si aucune n'existe
          const newSession = await createNewSession();
          if (!isMounted) return;
          setCurrentSessionId(newSession.id);
          setMessages([]);
          const updatedSessions = await getSessions();
          setSessions(updatedSessions);
        }
      } catch (error) {
        console.error("[FI9][ERROR] initChat:", error);
        if (isMounted) {
          Alert.alert(
            "Erreur",
            "Impossible de charger la session de conversation."
          );
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    initChat();

    return () => {
      isMounted = false;
    };
  }, []);

  // Auto-scroll FI9 stable avec timeout (évite les conflits)
  useEffect(() => {
    if (!messages || messages.length === 0 || loading) return;
    if (!flatListRef.current) return;

    if (scrollTimeoutRef.current) {
      clearTimeout(scrollTimeoutRef.current);
    }

    scrollTimeoutRef.current = setTimeout(() => {
      try {
        flatListRef.current?.scrollToEnd({ animated: true });
      } catch (e) {
        console.warn("[FI9][WARN] scrollToEnd failed:", e?.message);
      }
    }, 150);

    return () => {
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
    };
  }, [messages.length, loading]);

  // ============================================
  // 6. CALLBACK HOOKS (tous les useCallback)
  // ============================================
  const persistMessages = useCallback(
    async (nextMessages) => {
      if (!currentSessionId) return;
      try {
        const messagesToSave = nextMessages.filter((msg) => !msg.pending);
        if (messagesToSave.length > 0) {
          await saveMessages(currentSessionId, messagesToSave);
        }
      } catch (error) {
        console.error("[FI9][ERROR] persistMessages:", error);
      }
    },
    [currentSessionId]
  );

  const handleSendMessage = useCallback(
    async (text) => {
      const content = text.trim();
      if (!content || !currentSessionId || sending || !token) {
        if (!token) {
          Alert.alert("Session", "Veuillez vous reconnecter");
          navigation.replace("Login");
        }
        return;
      }

      setSending(true);

      const userMessage = {
        id: `user-${Date.now()}`,
        role: "user",
        content,
        timestamp: Date.now(),
      };

      setMessages((prev) => {
        const next = [...prev, userMessage];
        persistMessages(next).catch((err) =>
          console.error("[FI9][ERROR] persistMessages async:", err)
        );
        return next;
      });

      try {
        setIsTyping(true);
        const responseMessages = await sendMessage(
          content,
          token,
          currentSessionId
        );

        if (Array.isArray(responseMessages) && responseMessages.length > 0) {
          setMessages((prev) => {
            const existingIds = new Set(prev.map((m) => m.id));
            const newMessages = responseMessages.filter(
              (m) => !existingIds.has(m.id)
            );
            if (newMessages.length === 0) {
              return prev;
            }
            const merged = [...prev, ...newMessages];
            persistMessages(merged).catch((err) =>
              console.error("[FI9][ERROR] persistMessages async:", err)
            );
            return merged;
          });
        } else {
          const assistantMessage = {
            id: `assistant-${Date.now()}`,
            role: "assistant",
            content:
              "Je n'ai pas pu générer de réponse pour cette requête.",
            timestamp: Date.now(),
          };

          setMessages((prev) => {
            const next = [...prev, assistantMessage];
            persistMessages(next).catch((err) =>
              console.error("[FI9][ERROR] persistMessages async:", err)
            );
            return next;
          });
        }
      } catch (error) {
        console.error("[FI9][ERROR] handleSendMessage:", error);
        Alert.alert(
          "Erreur",
          "Une erreur est survenue lors de l'envoi du message."
        );
      } finally {
        setSending(false);
        setIsTyping(false);
      }
    },
    [currentSessionId, token, persistMessages, sending, navigation]
  );

  const handleSelectSession = useCallback(
    async (sessionId) => {
      if (!sessionId || sessionId === currentSessionId) return;

      setLoading(true);

      try {
        if (currentSessionId && messages.length > 0) {
          const messagesToSave = messages.filter((msg) => !msg.pending);
          if (messagesToSave.length > 0) {
            await saveMessages(currentSessionId, messagesToSave);
          }
        }

        const storedMessages = await getMessages(sessionId);
        setCurrentSessionId(sessionId);
        setMessages(storedMessages || []);
        await saveCurrentSession(sessionId);
      } catch (error) {
        console.error("[FI9][ERROR] handleSelectSession:", error);
        Alert.alert(
          "Erreur",
          "Impossible de charger l'historique de cette conversation."
        );
      } finally {
        setLoading(false);
      }
    },
    [currentSessionId, messages]
  );

  const handleNewChat = useCallback(async () => {
    if (currentSessionId && messages.length > 0) {
      const messagesToSave = messages.filter((msg) => !msg.pending);
      if (messagesToSave.length > 0) {
        await saveMessages(currentSessionId, messagesToSave);
      }
    }

    const newSession = await createNewSession();
    setCurrentSessionId(newSession.id);
    setMessages([]);
    await saveCurrentSession(newSession.id);
    const updatedSessions = await getSessions();
    setSessions(updatedSessions);
  }, [currentSessionId, messages]);

  const handleAttachmentPress = useCallback(() => {
    setIsAttachmentsSheetVisible(true);
  }, []);

  const handleImagePress = useCallback(() => {
    Alert.alert(t("image") || "Image", "Image selection (UI only)");
  }, [t]);

  const handleFilePress = useCallback(() => {
    Alert.alert(t("file") || "File", "File selection (UI only)");
  }, [t]);

  const handleScanPress = useCallback(() => {
    Alert.alert(t("scan") || "Scan", "Scan document (UI only)");
  }, [t]);

  const handleImportPress = useCallback(() => {
    Alert.alert(t("importDocument") || "Import", "Import document (UI only)");
  }, [t]);

  // FI9_UI_UPGRADE v15.0 - Navigation callbacks for EnhancedSidebar
  const handleHistory = useCallback(() => {
    // TODO: Navigate to history screen if exists
    Alert.alert(t("history") || "History", "History screen (to be implemented)");
  }, [t]);

  const handleSettings = useCallback(() => {
    // TODO: Navigate to settings screen if exists
    Alert.alert(t("settings") || "Settings", "Settings screen (to be implemented)");
  }, [t]);

  const handleGPTs = useCallback(() => {
    Alert.alert("GPTs", "GPTs marketplace (to be implemented)");
  }, []);

  const handleTools = useCallback(() => {
    Alert.alert("Tools", "Tools marketplace (to be implemented)");
  }, []);

  const handleMarketplace = useCallback(() => {
    Alert.alert(t("marketplace") || "Marketplace", "Marketplace (to be implemented)");
  }, [t]);

  // FI9_UI_UPGRADE v15.0 - Subscription navigation
  const handleNavigateToSubscription = useCallback(() => {
    // TODO: Navigate to subscription/billing screen if exists
    Alert.alert("Abonnement", "Redirection vers le portail d'abonnement...");
  }, []);

  // FI9_UI_UPGRADE v15.0 - Voice input handler
  const handleVoiceTextReceived = useCallback((text) => {
    // Inject text into EnhancedMessageInput
    // This will be handled by EnhancedMessageInput internally
    if (text && text.trim()) {
      handleSendMessage(text);
    }
  }, [handleSendMessage]);

  const renderMessageItem = useCallback(
    ({ item, index }) => (
      <AnimatedMessageBubble
        role={item.role}
        content={item.content}
        username={item.role === "user" ? username : undefined}
        onTTS={undefined}
        index={index}
      />
    ),
    [username]
  );

  const keyExtractor = useCallback((item) => String(item.id), []);

  const renderEmpty = useCallback(
    () => (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>
          {t("emptyChat") || "Aucune conversation"}
        </Text>
        <Text style={styles.emptySubtext}>
          {t("emptySubtext") || "Commencez une nouvelle conversation"}
        </Text>
      </View>
    ),
    [styles, t]
  );

  // ============================================
  // 7. CONDITIONAL RETURN (APRÈS TOUS LES HOOKS)
  // ============================================
  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={theme.text} />
      </View>
    );
  }

  // ============================================
  // 8. MAIN RETURN (JSX principal)
  // ============================================
  // FI9_FIX v20.0 - Structure corrigée avec zIndex et paddingBottom synchronisés
  // ✅ Messages visibles avec zIndex: 1
  // ✅ Sidebar visible avec zIndex: 100
  // ✅ Input au-dessus avec zIndex: 50
  // ✅ paddingBottom: 90 = height: 90 de l'input

  // Protection bug visuel - Debug
  console.log("[FI9_CHAT] nombre de messages =", messages?.length);

  // Alias pour renderMessage (compatibilité)
  const renderMessage = renderMessageItem;

  return (
    <View style={{ flex: 1, backgroundColor: "#000" }}>
      {/* SIDEBAR */}
      <EnhancedSidebar />

      {/* ZONE PRINCIPALE */}
      <View style={{ flex: 1 }}>
        {/* ZONE MESSAGES */}
        <View style={{ flex: 1, paddingBottom: 90, zIndex: 1 }}>
          <FlatList
            ref={flatListRef}
            data={messages}
            keyExtractor={keyExtractor}
            renderItem={renderMessage}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={{
              paddingTop: 12,
              paddingBottom: 12,
            }}
            ListEmptyComponent={renderEmpty}
          />
          {isTyping && <ChatTypingIndicator visible={true} />}
        </View>

        {/* ZONE INPUT — TOUJOURS AU-DESSUS */}
        <View
          style={{
            position: "absolute",
            bottom: 0,
            left: 0,
            right: 0,
            height: 90,
            backgroundColor: "#000",
            borderTopWidth: 1,
            borderTopColor: "#222",
            justifyContent: "center",
            zIndex: 50,
          }}
        >
          {UI_V15_INPUT_ENABLED ? (
            <EnhancedMessageInput
              disabled={sending || status !== "authenticated"}
              onSend={handleSendMessage}
              onAttachmentPress={handleAttachmentPress}
              placeholder={t("placeholder") || "Message..."}
              showMarkdownPreview={true}
              showCodeBlockButton={true}
              enableVoice={UI_V15_VOICE_ENABLED}
              onVoiceTextReceived={handleVoiceTextReceived}
            />
          ) : (
            <Composer
              disabled={sending || status !== "authenticated"}
              onSend={handleSendMessage}
              onAttachmentPress={handleAttachmentPress}
            />
          )}
        </View>
      </View>

      {/* FI9_PATCH v14.0: Bottom Sheet pour attachments */}
      <FI9_AttachmentsSheet
        visible={isAttachmentsSheetVisible}
        onClose={() => setIsAttachmentsSheetVisible(false)}
        onImagePress={handleImagePress}
        onFilePress={handleFilePress}
        onScanPress={handleScanPress}
        onImportPress={handleImportPress}
      />
    </View>
  );
}
