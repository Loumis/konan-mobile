// FI9_NAYEK v14: API client wrapper - re-exports from client.ts
// This file provides a .js export for compatibility
import { API } from "./client";

// Re-export the API instance
export { API };
export default API;

