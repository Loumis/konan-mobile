/**
 * FI9_NAYEK: Universal API Base URL Detection (RN + Web)
 * Stable implementation using Platform.OS with environment variable support
 */
import { Platform } from "react-native";

// FI9_NAYEK: Priorité inversée - API_BASE_URL AVANT VITE_API_BASE_URL
// Suppression de toute résolution vers localhost
const ENV_API_BASE_URL = 
  process.env.EXPO_PUBLIC_API_URL ||
  process.env.API_BASE_URL ||
  process.env.VITE_API_BASE_URL;

// Normaliser: remplacer localhost par IP LAN
const normalizeURL = (url: string | undefined): string | undefined => {
  if (!url) return undefined;
  const normalized = url.trim().replace(/\/+$/, '');
  // Remplacer localhost/127.0.0.1 par IP LAN
  if (normalized.includes('localhost') || normalized.includes('127.0.0.1')) {
    return 'http://192.168.0.184:8000';
  }
  return normalized;
};

const NORMALIZED_ENV_URL = normalizeURL(ENV_API_BASE_URL);

// Debug: Log environment variable detection
if (__DEV__) {
  console.log('[FI9_ENV] Environment variables check:', {
    EXPO_PUBLIC_API_URL: process.env.EXPO_PUBLIC_API_URL || 'not set',
    API_BASE_URL: process.env.API_BASE_URL || 'not set',
    VITE_API_BASE_URL: process.env.VITE_API_BASE_URL || 'not set',
    raw: ENV_API_BASE_URL || 'not set',
    normalized: NORMALIZED_ENV_URL || 'not set',
  });
}

// Fallback: uniquement LAN IP (plus de localhost)
const LAN_API = "http://192.168.0.184:8000";

/**
 * Check if we're in a web environment (React Native safe)
 */
function isWebEnv() {
  if (typeof window === "undefined") return false;
  if (typeof window.location === "undefined") return false;
  return true;
}

export function getAPIBaseURL() {
  // Priority 1: Use normalized environment variable if set
  if (NORMALIZED_ENV_URL) {
    const resolved = NORMALIZED_ENV_URL;
    console.log(`[FI9] API Base URL resolved: ${resolved} (from env)`);
    return resolved;
  }

  // Priority 2: Platform-specific logic (fallback)
  // React Native Mobile (Android/iOS) - toujours LAN IP
  if (Platform.OS === "android" || Platform.OS === "ios") {
    console.log(`[FI9] API Base URL resolved: ${LAN_API} (Android/iOS fallback)`);
    return LAN_API;
  }

  // Web environment - toujours LAN IP (plus de localhost)
  if (isWebEnv()) {
    const host = window.location.hostname;

    // Local network IP detection (192.x, 10.x, 172.x)
    if (host.startsWith("192.") || host.startsWith("10.") || host.startsWith("172.")) {
      console.log(`[FI9] API Base URL resolved: ${LAN_API} (LAN hostname: ${host})`);
      return LAN_API;
    }

    // Plus de localhost - toujours LAN IP
    console.log(`[FI9] API Base URL resolved: ${LAN_API} (Web fallback, hostname: ${host})`);
    return LAN_API;
  }

  // Default fallback (should not happen, but safety net)
  console.log(`[FI9] API Base URL resolved: ${LAN_API} (default fallback)`);
  return LAN_API;
}

// Export singleton instance
export const API_BASE_URL = getAPIBaseURL();

// Log final de la valeur résolue
console.log(`[FI9] ✅ API Base URL FINAL RESOLVED: ${API_BASE_URL} (Platform: ${Platform.OS})`);
