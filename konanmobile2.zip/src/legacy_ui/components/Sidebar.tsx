// LEGACY_FI9: fichier déplacé automatiquement, plus utilisé par l'app mobile
/**
 * FI9_NAYEK: Fixed sidebar with conversations list
 */
import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  TextInput,
  ActivityIndicator,
} from 'react-native';
// LEGACY_FI9: Imports corrigés pour pointer vers legacy_ui
import { useKonanTheme } from '../../hooks/useKonanTheme';
import { PrimaryGradient } from '../../styles/gradients';
import { Avatar } from '../../components/Avatar';

export interface Conversation {
  id: string;
  title: string;
  preview?: string;
  updatedAt: Date | string;
  isActive?: boolean;
}

interface SidebarProps {
  conversations: Conversation[];
  activeConversationId?: string;
  onConversationSelect: (id: string) => void;
  onNewChat: () => void;
  onSearch?: () => void;
  onLibrary?: () => void;
  loading?: boolean;
  style?: any;
}

export const Sidebar: React.FC<SidebarProps> = ({
  conversations,
  activeConversationId,
  onConversationSelect,
  onNewChat,
  onSearch,
  onLibrary,
  loading = false,
  style,
}) => {
  const theme = useKonanTheme();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredConversations = conversations.filter((conv) =>
    conv.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatDate = (date: Date | string) => {
    const d = typeof date === 'string' ? new Date(date) : date;
    const now = new Date();
    const diffMs = now.getTime() - d.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'À l\'instant';
    if (diffMins < 60) return `Il y a ${diffMins} min`;
    if (diffHours < 24) return `Il y a ${diffHours}h`;
    if (diffDays < 7) return `Il y a ${diffDays}j`;
    return d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
  };

  const truncateText = (text: string, maxLength: number = 50) => {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  };

  const renderConversationItem = ({ item }: { item: Conversation }) => {
    const isActive = item.id === activeConversationId;

    return (
      <TouchableOpacity
        onPress={() => onConversationSelect(item.id)}
        style={[
          styles.conversationItem,
          {
            backgroundColor: isActive ? theme.colors.surfaceActive : 'transparent',
            borderRadius: theme.radius.lg,
            paddingHorizontal: theme.spacing.md,
            paddingVertical: theme.spacing.sm,
            marginHorizontal: theme.spacing.sm,
            marginVertical: 2,
          },
          isActive && {
            borderLeftWidth: 3,
            borderLeftColor: theme.colors.primary,
          },
        ]}
        accessibilityRole="button"
        accessibilityLabel={`Conversation: ${item.title}`}
      >
        <Text
          style={[
            styles.conversationTitle,
            {
              color: isActive ? theme.colors.text : theme.colors.textSecondary,
              fontSize: theme.typography.sm.fontSize,
              fontWeight: isActive ? '600' : '400',
            },
          ]}
          numberOfLines={1}
        >
          {item.title || 'Sans titre'}
        </Text>
        {item.preview && (
          <Text
            style={[
              styles.conversationPreview,
              {
                color: theme.colors.textMuted,
                fontSize: theme.typography.xs.fontSize,
              },
            ]}
            numberOfLines={1}
          >
            {truncateText(item.preview, 40)}
          </Text>
        )}
        <Text
          style={[
            styles.conversationDate,
            {
              color: theme.colors.textMuted,
              fontSize: theme.typography.xs.fontSize,
            },
          ]}
        >
          {formatDate(item.updatedAt)}
        </Text>
      </TouchableOpacity>
    );
  };

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: theme.colors.bg,
          width: 280,
          borderRightColor: theme.colors.border,
        },
        style,
      ]}
      accessibilityRole="navigation"
      accessibilityLabel="Sidebar navigation"
    >
      {/* Logo Section */}
      <View style={[styles.logoSection, { padding: theme.spacing.lg }]}>
        <PrimaryGradient
          style={[
            styles.logo,
            {
              width: 48,
              height: 48,
              borderRadius: 24,
            },
          ]}
        >
          <Text style={styles.logoText}>K</Text>
        </PrimaryGradient>
        <Text
          style={[
            styles.logoTitle,
            {
              color: theme.colors.text,
              fontSize: theme.typography.lg.fontSize,
              fontWeight: '700',
              marginTop: theme.spacing.sm,
            },
          ]}
        >
          KONAN
        </Text>
      </View>

      {/* Action Buttons */}
      <View style={[styles.actionsSection, { paddingHorizontal: theme.spacing.md }]}>
        <TouchableOpacity
          onPress={onNewChat}
          style={[
            styles.actionButton,
            {
              backgroundColor: theme.colors.surface,
              borderRadius: theme.radius.lg,
              paddingVertical: theme.spacing.md,
              paddingHorizontal: theme.spacing.lg,
              marginBottom: theme.spacing.sm,
            },
          ]}
          accessibilityRole="button"
          accessibilityLabel="New chat"
        >
          <PrimaryGradient
            style={[
              styles.actionButtonGradient,
              {
                borderRadius: theme.radius.lg,
              },
            ]}
          >
            <Text
              style={[
                styles.actionButtonText,
                {
                  color: '#ffffff',
                  fontSize: theme.typography.sm.fontSize,
                  fontWeight: '600',
                },
              ]}
            >
              + Nouveau chat
            </Text>
          </PrimaryGradient>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={onSearch}
          style={[
            styles.actionButton,
            {
              backgroundColor: theme.colors.surface,
              borderRadius: theme.radius.lg,
              paddingVertical: theme.spacing.sm,
              paddingHorizontal: theme.spacing.md,
              marginBottom: theme.spacing.xs,
            },
          ]}
          accessibilityRole="button"
          accessibilityLabel="Search"
        >
          <Text
            style={[
              styles.actionButtonText,
              {
                color: theme.colors.textSecondary,
                fontSize: theme.typography.sm.fontSize,
              },
            ]}
          >
            🔍 Rechercher
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={onLibrary}
          style={[
            styles.actionButton,
            {
              backgroundColor: theme.colors.surface,
              borderRadius: theme.radius.lg,
              paddingVertical: theme.spacing.sm,
              paddingHorizontal: theme.spacing.md,
            },
          ]}
          accessibilityRole="button"
          accessibilityLabel="Library"
        >
          <Text
            style={[
              styles.actionButtonText,
              {
                color: theme.colors.textSecondary,
                fontSize: theme.typography.sm.fontSize,
              },
            ]}
          >
            📚 Bibliothèque
          </Text>
        </TouchableOpacity>
      </View>

      {/* Conversations List */}
      <View style={styles.conversationsSection}>
        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="small" color={theme.colors.primary} />
          </View>
        ) : (
          <FlatList
            data={filteredConversations}
            keyExtractor={(item) => item.id}
            renderItem={renderConversationItem}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={styles.emptyContainer}>
                <Text
                  style={[
                    styles.emptyText,
                    {
                      color: theme.colors.textMuted,
                      fontSize: theme.typography.sm.fontSize,
                    },
                  ]}
                >
                  Aucune conversation
                </Text>
              </View>
            }
          />
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderRightWidth: 1,
  },
  logoSection: {
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.05)',
  },
  logo: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoText: {
    color: '#ffffff',
    fontSize: 24,
    fontWeight: '700',
  },
  logoTitle: {
    fontWeight: '700',
  },
  actionsSection: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.05)',
  },
  actionButton: {
    overflow: 'hidden',
  },
  actionButtonGradient: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionButtonText: {
    fontWeight: '500',
  },
  conversationsSection: {
    flex: 1,
  },
  listContent: {
    paddingVertical: 8,
  },
  conversationItem: {
    marginVertical: 2,
  },
  conversationTitle: {
    fontWeight: '500',
    marginBottom: 2,
  },
  conversationPreview: {
    marginTop: 2,
  },
  conversationDate: {
    marginTop: 4,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 48,
  },
  emptyText: {
    textAlign: 'center',
  },
});
