// LEGACY_FI9: fichier déplacé automatiquement, plus utilisé par l'app mobile
/**
 * FI9_NAYEK: Typing indicator with 3 bouncing dots (ChatGPT style)
 * Uses CSS animation + RAF for web compatibility
 */
import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Animated, Platform } from 'react-native';
// LEGACY_FI9: Imports corrigés pour pointer vers legacy_ui
import { useKonanTheme } from '../../hooks/useKonanTheme';

interface TypingIndicatorProps {
  visible?: boolean;
  size?: number;
}

export const TypingIndicator: React.FC<TypingIndicatorProps> = ({
  visible = true,
  size = 8,
}) => {
  const theme = useKonanTheme();
  const anim1 = useRef(new Animated.Value(0)).current;
  const anim2 = useRef(new Animated.Value(0)).current;
  const anim3 = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!visible) return;

    const createAnimation = (animValue: Animated.Value, delay: number) => {
      return Animated.loop(
        Animated.sequence([
          Animated.delay(delay),
          Animated.timing(animValue, {
            toValue: 1,
            duration: 600,
            useNativeDriver: true,
          }),
          Animated.timing(animValue, {
            toValue: 0,
            duration: 600,
            useNativeDriver: true,
          }),
        ])
      );
    };

    const animations = [
      createAnimation(anim1, 0),
      createAnimation(anim2, 200),
      createAnimation(anim3, 400),
    ];

    animations.forEach((anim) => anim.start());

    return () => {
      animations.forEach((anim) => anim.stop());
    };
  }, [visible, anim1, anim2, anim3]);

  if (!visible) return null;

  const translateY1 = anim1.interpolate({
    inputRange: [0, 1],
    outputRange: [0, -8],
  });

  const translateY2 = anim2.interpolate({
    inputRange: [0, 1],
    outputRange: [0, -8],
  });

  const translateY3 = anim3.interpolate({
    inputRange: [0, 1],
    outputRange: [0, -8],
  });

  return (
    <View style={styles.container} accessibilityLabel="Typing indicator">
      <Animated.View
        style={[
          styles.dot,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
            backgroundColor: theme.colors.textMuted,
            transform: [{ translateY: translateY1 }],
          },
        ]}
      />
      <Animated.View
        style={[
          styles.dot,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
            backgroundColor: theme.colors.textMuted,
            transform: [{ translateY: translateY2 }],
          },
        ]}
      />
      <Animated.View
        style={[
          styles.dot,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
            backgroundColor: theme.colors.textMuted,
            transform: [{ translateY: translateY3 }],
          },
        ]}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  dot: {
    backgroundColor: '#9ca3af',
  },
});

