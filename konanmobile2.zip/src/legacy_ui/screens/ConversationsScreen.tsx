// LEGACY_FI9: fichier déplacé automatiquement, plus utilisé par l'app mobile
/**
 * FI9_NAYEK: Conversations Screen with Sidebar
 */
import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Text } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
// LEGACY_FI9: Imports corrigés pour pointer vers legacy_ui
import { useKonanTheme } from '../../hooks/useKonanTheme';
import { Sidebar, Conversation } from '../components/Sidebar';

interface ConversationsScreenProps {
  navigation?: any;
}

export default function ConversationsScreen({ navigation }: ConversationsScreenProps) {
  const theme = useKonanTheme();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | undefined>();
  const [loading, setLoading] = useState(true);

  // Load conversations
  useEffect(() => {
    loadConversations();
  }, []);

  const loadConversations = async () => {
    setLoading(true);
    try {
      // TODO: Replace with actual API call
      // const data = await fetchConversations();
      
      // Mock data
      const mockConversations: Conversation[] = [
        {
          id: '1',
          title: 'Première conversation',
          preview: 'Bonjour, comment puis-je vous aider ?',
          updatedAt: new Date(),
        },
        {
          id: '2',
          title: 'Discussion sur React Native',
          preview: 'Comment créer un composant réutilisable ?',
          updatedAt: new Date(Date.now() - 3600000),
        },
      ];
      
      setConversations(mockConversations);
    } catch (error) {
      console.error('Error loading conversations:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleNewChat = () => {
    setActiveConversationId('new');
    // Navigate to chat screen
    if (navigation) {
      navigation.navigate('Chat', { conversationId: 'new' });
    }
  };

  const handleConversationSelect = (id: string) => {
    setActiveConversationId(id);
    if (navigation) {
      navigation.navigate('Chat', { conversationId: id });
    }
  };

  const handleSearch = () => {
    // TODO: Implement search
    console.log('Search clicked');
  };

  const handleLibrary = () => {
    // TODO: Implement library
    console.log('Library clicked');
  };

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: theme.colors.bg }]}
      edges={['top', 'bottom']}
    >
      <View style={styles.content}>
        <Sidebar
          conversations={conversations}
          activeConversationId={activeConversationId}
          onConversationSelect={handleConversationSelect}
          onNewChat={handleNewChat}
          onSearch={handleSearch}
          onLibrary={handleLibrary}
          loading={loading}
        />
        
        {/* Main chat area - will be replaced by navigation in real app */}
        <View style={styles.chatArea}>
          <View style={styles.placeholder}>
            <Text style={{ color: theme.colors.textMuted, textAlign: 'center', marginTop: 48 }}>
              Sélectionnez une conversation ou créez-en une nouvelle
            </Text>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    flexDirection: 'row',
  },
  chatArea: {
    flex: 1,
  },
  placeholder: {
    flex: 1,
  },
});

