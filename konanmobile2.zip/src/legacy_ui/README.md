# Legacy UI Components

Ce dossier contient les composants UI obsolètes ou non utilisés qui ont été mis de côté pour nettoyer le projet.

**IMPORTANT**: Ces fichiers ne sont PAS supprimés, seulement déplacés pour éviter la confusion.

## Fichiers déplacés

### Screens
- `AuthTest.js` - Composant de test d'authentification (non utilisé)
- `PdfPreviewScreen.jsx` - Écran de prévisualisation PDF (non utilisé)

### Components
- `CitationChips.jsx` - Composant de citations (non utilisé)
- `PlanGate.jsx` - Composant de gate pour plans (non utilisé)
- `ApiTester.jsx` - Composant de test API (debug, non utilisé en prod)
- `FI9_DEBUG_TOKEN.jsx` - Composant de debug token (debug, non utilisé en prod)
- `HeaderDynamic.tsx` - Header dynamique (non utilisé)
- `SidebarKonan.tsx` - Sidebar alternative (non utilisé)
- `AttachmentBar.jsx` - Barre d'attachements (remplacé par ChatAttachmentBar.jsx)

## Fichiers NON déplacés (utilisés ailleurs)

Les fichiers suivants sont utilisés par d'autres parties du code et ne peuvent pas être déplacés :

- `SettingsScreen.tsx` - Utilise `useKonanTheme` (peut être utilisé ailleurs)
- `ChatInput.tsx` - Utilise `useKonanTheme` (peut être utilisé ailleurs)
- `MessageInput.jsx` - Utilisé par `ChatArea.jsx` (version web)
- `ChatArea.jsx` - Utilisé par `App.jsx` (version web)
- `ChatBubble.tsx` - Utilisé par `messageTools.ts`
- `Sidebar.jsx` - Utilisé par `App.jsx` et `ConversationsScreen.tsx`
- `Sidebar.tsx` - Utilisé par `ConversationsScreen.tsx`
- `Avatar.tsx` - Utilisé par plusieurs composants
- `Header.tsx` - Exporté dans `index.ts`
- `StatusIndicator.tsx` - Exporté dans `index.ts`
- `TypingIndicator.tsx` - Utilise `useKonanTheme`
- `MessageCompressor.tsx` - Exporté dans `index.ts`
- `useKonanTheme.ts` - Utilisé par plusieurs fichiers
- `ChatUIContext.tsx` - Utilisé par `useAutoScroll.ts` et `useMessageCompression.ts`
- `useAutoScroll.ts` - Utilise `ChatUIContext`
- `useMessageCompression.ts` - Utilise `ChatUIContext`
- `ThemeContext.tsx` - Utilisé par `ThemeProvider.tsx`

## Restauration

Si vous avez besoin de restaurer un fichier, déplacez-le simplement depuis `legacy_ui/` vers son emplacement d'origine.

