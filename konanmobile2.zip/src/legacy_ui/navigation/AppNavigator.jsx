// LEGACY_FI9: fichier déplacé automatiquement, plus utilisé par l'app mobile
// FI9_NAYEK: AppNavigator avec navigation dynamique basée sur l'auth status
import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { useAuth } from "../../hooks/useAuth";
import { View, ActivityIndicator, Text, StyleSheet } from "react-native";

// LEGACY_FI9: Imports corrigés pour pointer vers les screens actifs
import LoginScreen from "../../screens/LoginScreen";
import RegisterScreen from "../../screens/RegisterScreen";
import ChatScreen from "../../screens/ChatScreen";
import ConversationsScreen from "../screens/ConversationsScreen.tsx";
import SubscribeScreen from "../../screens/SubscribeScreen";

const Stack = createNativeStackNavigator();

export default function AppNavigator() {
  const { status, isAuthenticated } = useAuth();

  // FI9_NAYEK: Attendre que le token soit chargé avant de rendre la navigation
  if (status === "loading") {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#FFFFFF" />
        <Text style={styles.loadingText}>[FI9] Chargement du token...</Text>
      </View>
    );
  }

  // FI9_NAYEK: Route initiale dynamique selon l'auth status
  const initialRouteName = isAuthenticated ? "Chat" : "Login";

  console.log(`[FI9] AppNavigator - Status: ${status}, isAuthenticated: ${isAuthenticated}, initialRoute: ${initialRouteName}`);

  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName={initialRouteName}
        screenOptions={{
          headerShown: false,
          animation: "fade_from_bottom",
        }}
      >
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Register" component={RegisterScreen} />
        <Stack.Screen name="Chat" component={ChatScreen} />
        <Stack.Screen name="Conversations" component={ConversationsScreen} />
        <Stack.Screen name="Subscribe" component={SubscribeScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#0B0B0B",
  },
  loadingText: {
    color: "#FFFFFF",
    marginTop: 12,
    fontSize: 14,
  },
});
