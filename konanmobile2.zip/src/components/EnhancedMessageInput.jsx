// FI9_UI_UPGRADE v15.0 - Enhanced Message Input Component
// Advanced input with markdown preview, IME support, code blocks, debounce
// Preserves all existing KONAN logic - UI only upgrade

import React, { useState, useRef, useCallback, useMemo, useEffect, memo } from "react";
import {
  View,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Platform,
  Text,
  ScrollView,
  Keyboard,
  NativeModules,
} from "react-native";
import { useLanguage } from "../context/LanguageContext";
import { useAppTheme } from "../context/AppThemeContext";
import { chatColors } from "../constants/colors";
import VoiceInput from "./VoiceInput";

// Try to import markdown renderer
let Markdown = null;
try {
  Markdown = require("react-native-markdown-display");
} catch (e) {
  Markdown = null;
}

// Icons
let SendIcon = null;
let CodeIcon = null;
let EyeIcon = null;
let EyeOffIcon = null;
try {
  const lucide = require("lucide-react-native");
  if (lucide) {
    SendIcon = lucide.Send;
    CodeIcon = lucide.Code;
    EyeIcon = lucide.Eye;
    EyeOffIcon = lucide.EyeOff;
  }
} catch (e) {
  // Fallback to Ionicons
}

let Ionicons = null;
try {
  const vectorIcons = require("@expo/vector-icons");
  if (vectorIcons && vectorIcons.Ionicons) {
    Ionicons = vectorIcons.Ionicons;
  }
} catch (e) {
  Ionicons = null;
}

// Haptics
let Haptics = null;
try {
  Haptics = require("expo-haptics");
} catch (e) {
  Haptics = null;
}

const DEBOUNCE_DELAY = 300; // Anti-spam debounce
const MAX_LENGTH = 4000;

export const EnhancedMessageInput = memo(({
  onSend,
  disabled = false,
  onAttachmentPress,
  placeholder,
  maxLength = MAX_LENGTH,
  showMarkdownPreview = true,
  showCodeBlockButton = true,
  enableVoice = false,
  onVoiceTextReceived,
}) => {
  // ============================================
  // HOOKS
  // ============================================
  const { t } = useLanguage();
  const { theme } = useAppTheme();
  const inputRef = useRef(null);
  const scrollViewRef = useRef(null);
  const debounceTimerRef = useRef(null);

  // ============================================
  // STATE
  // ============================================
  const [text, setText] = useState("");
  const [inputState, setInputState] = useState("idle"); // idle, typing, composing, recording
  const [isRecording, setIsRecording] = useState(false);
  const [isComposing, setIsComposing] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  // ============================================
  // HANDLERS
  // ============================================
  const handleChangeText = useCallback((value) => {
    setText(value);
    setInputState("typing");

    // Debounce anti-spam
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    debounceTimerRef.current = setTimeout(() => {
      setInputState("idle");
    }, DEBOUNCE_DELAY);
  }, []);

  const handleKeyPress = useCallback((e) => {
    // Enter = send, Shift+Enter = new line
    // Note: React Native doesn't support shiftKey detection well
    // We'll use onSubmitEditing for Enter key
  }, []);

  const handleSend = useCallback(() => {
    const trimmed = text.trim();
    if (!trimmed || !onSend || disabled) return;

    // Haptic feedback
    if (Haptics && Platform.OS !== "web") {
      try {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      } catch (e) {
        // Ignore
      }
    }

    onSend(trimmed);
    setText("");
    setInputState("idle");
    inputRef.current?.focus();
  }, [text, onSend, disabled]);

  const handleCompositionStart = useCallback(() => {
    setIsComposing(true);
    setInputState("composing");
  }, []);

  const handleCompositionEnd = useCallback(() => {
    setIsComposing(false);
    setInputState("idle");
  }, []);

  // FI9_UI_UPGRADE v15.0 - Voice input handler
  const handleVoiceTextReceived = useCallback((transcribedText) => {
    if (transcribedText && transcribedText.trim()) {
      setText((prev) => prev + (prev ? " " : "") + transcribedText);
      setInputState("typing");
      // Auto-focus input after voice input
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, []);

  const handleVoiceError = useCallback((error) => {
    console.error("[FI9] Voice input error:", error);
    setInputState("idle");
  }, []);

  const insertCodeBlock = useCallback(() => {
    const codeBlock = "\n```\n\n```\n";
    const newText = text + codeBlock;
    setText(newText);
    
    // Focus and position cursor
    setTimeout(() => {
      if (inputRef.current) {
        inputRef.current.focus();
        // Position cursor before closing ```
        const position = newText.length - 4;
        // Note: setNativeProps might be needed for cursor positioning
      }
    }, 100);
  }, [text]);

  const togglePreview = useCallback(() => {
    setShowPreview((prev) => !prev);
  }, []);

  // ============================================
  // KEYBOARD HANDLING (Mobile)
  // ============================================
  useEffect(() => {
    if (Platform.OS !== "web") {
      // Keyboard handling is managed by KeyboardAvoidingView in parent
      // This effect is for future enhancements
    }
  }, []);

  // ============================================
  // STYLES
  // ============================================
  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          width: "100%",
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 10,
          paddingVertical: 8,
          backgroundColor: "#111",
        },
        inputWrapper: {
          flex: 1,
          position: "relative",
        },
        input: {
          flex: 1,
          minHeight: 40,
          maxHeight: 120,
          paddingHorizontal: 14,
          paddingVertical: 10,
          borderRadius: 20,
          backgroundColor: theme.surface || chatColors.surface,
          fontSize: 16,
          color: theme.text || chatColors.textPrimary,
          textAlignVertical: "top",
        },
        previewContainer: {
          backgroundColor: theme.surface || chatColors.surface,
          borderRadius: 20,
          padding: 12,
          marginTop: 8,
          maxHeight: 200,
        },
        previewText: {
          fontSize: 14,
          color: theme.text || chatColors.textPrimary,
        },
        toolbar: {
          flexDirection: "row",
          alignItems: "center",
          gap: 8,
          marginTop: 4,
          paddingHorizontal: 4,
        },
        toolbarButton: {
          width: 32,
          height: 32,
          borderRadius: 16,
          backgroundColor: theme.surface || chatColors.surface,
          alignItems: "center",
          justifyContent: "center",
        },
        sendButton: {
          marginLeft: 8,
          width: 40,
          height: 40,
          borderRadius: 20,
          alignItems: "center",
          justifyContent: "center",
        },
        sendButtonDisabled: {
          opacity: 0.5,
        },
      }),
    [theme]
  );

  const canSend = text.trim().length > 0 && !disabled && inputState !== "composing";

  // ============================================
  // RENDER
  // ============================================
  return (
    <View style={styles.container}>
      {/* Attachment button */}
      {onAttachmentPress && (
        <TouchableOpacity
          style={styles.toolbarButton}
          onPress={onAttachmentPress}
          activeOpacity={0.7}
        >
          {Ionicons ? (
            <Ionicons
              name="add"
              size={18}
              color={theme.text || chatColors.textPrimary}
            />
          ) : (
            <Text style={{ fontSize: 18, color: theme.text || chatColors.textPrimary }}>+</Text>
          )}
        </TouchableOpacity>
      )}

      {/* Voice Input Button */}
      {enableVoice && (
        <VoiceInput
          onTextReceived={onVoiceTextReceived || handleVoiceTextReceived}
          onError={handleVoiceError}
          disabled={disabled}
          style={{ marginRight: 4 }}
        />
      )}

      <View style={styles.inputWrapper}>
        <TextInput
          ref={inputRef}
          style={styles.input}
          value={text}
          onChangeText={handleChangeText}
          onCompositionStart={handleCompositionStart}
          onCompositionEnd={handleCompositionEnd}
          onSubmitEditing={Platform.OS === "ios" ? undefined : handleSend}
          returnKeyType={Platform.OS === "ios" ? "default" : "send"}
          placeholder={placeholder || t("placeholder") || "Message..."}
          placeholderTextColor={theme.textMuted || chatColors.textMuted}
          multiline
          maxLength={maxLength}
          editable={!disabled}
          returnKeyType="default"
          blurOnSubmit={false}
          textAlignVertical="top"
          // IME support (Arabic, Chinese, etc.)
          textContentType="none"
          autoCorrect={true}
          autoCapitalize="sentences"
          keyboardType="default"
        />

        {/* Markdown Preview */}
        {showPreview && text.trim() && Markdown && (
          <ScrollView
            ref={scrollViewRef}
            style={styles.previewContainer}
            nestedScrollEnabled={true}
          >
            <Markdown>{text}</Markdown>
          </ScrollView>
        )}

        {/* Toolbar */}
        {(showMarkdownPreview || showCodeBlockButton) && text.trim().length > 0 && (
          <View style={styles.toolbar}>
            {showMarkdownPreview && (
              <TouchableOpacity
                style={styles.toolbarButton}
                onPress={togglePreview}
                activeOpacity={0.7}
              >
                {showPreview ? (
                  EyeOffIcon ? (
                    <EyeOffIcon
                      size={16}
                      color={theme.textMuted || chatColors.textMuted}
                    />
                  ) : Ionicons ? (
                    <Ionicons
                      name="eye-off-outline"
                      size={16}
                      color={theme.textMuted || chatColors.textMuted}
                    />
                  ) : (
                    <Text style={{ fontSize: 14 }}>👁️</Text>
                  )
                ) : (
                  EyeIcon ? (
                    <EyeIcon
                      size={16}
                      color={theme.textMuted || chatColors.textMuted}
                    />
                  ) : Ionicons ? (
                    <Ionicons
                      name="eye-outline"
                      size={16}
                      color={theme.textMuted || chatColors.textMuted}
                    />
                  ) : (
                    <Text style={{ fontSize: 14 }}>👁️</Text>
                  )
                )}
              </TouchableOpacity>
            )}

            {showCodeBlockButton && (
              <TouchableOpacity
                style={styles.toolbarButton}
                onPress={insertCodeBlock}
                activeOpacity={0.7}
              >
                {CodeIcon ? (
                  <CodeIcon
                    size={16}
                    color={theme.textMuted || chatColors.textMuted}
                  />
                ) : Ionicons ? (
                  <Ionicons
                    name="code-outline"
                    size={16}
                    color={theme.textMuted || chatColors.textMuted}
                  />
                ) : (
                  <Text style={{ fontSize: 14 }}>{"</>"}</Text>
                )}
              </TouchableOpacity>
            )}
          </View>
        )}
      </View>

      {/* Send Button - Dans le même container, suit strictement l'input */}
      <TouchableOpacity
        style={[styles.sendButton, (!canSend || disabled) && styles.sendButtonDisabled]}
        onPress={handleSend}
        disabled={!canSend}
        activeOpacity={0.7}
      >
        {SendIcon ? (
          <SendIcon
            size={20}
            color={!canSend || disabled ? chatColors.textMuted : chatColors.accent}
            strokeWidth={2}
          />
        ) : Ionicons ? (
          <Ionicons
            name="arrow-forward"
            size={20}
            color={!canSend || disabled ? (theme.textMuted || chatColors.textMuted) : (theme.primary || chatColors.accent)}
          />
        ) : (
          <Text style={{ fontSize: 18, color: !canSend || disabled ? chatColors.textMuted : chatColors.accent }}>
            →
          </Text>
        )}
      </TouchableOpacity>
    </View>
  );
});

EnhancedMessageInput.displayName = "EnhancedMessageInput";

export default EnhancedMessageInput;

