// FI9_PATCH v13.3 - ChatSidebarModal component
// Drawer modal pour mobile (non overlay permanent)
import React from "react";
import { View, StyleSheet, Modal, TouchableOpacity, Platform } from "react-native";
import { useAppTheme } from "../context/AppThemeContext";
import { chatColors } from "../constants/colors";
import ChatSidebar from "./ChatSidebar";

export default function ChatSidebarModal({
  visible,
  onClose,
  sessions,
  currentSessionId,
  onSelectSession,
  onNewChat,
  user,
  onLogout,
}) {
  const { theme } = useAppTheme();

  const styles = StyleSheet.create({
    modalContainer: {
      flex: 1,
      flexDirection: "row",
    },
    modalOverlay: {
      flex: 1,
      backgroundColor: "rgba(0,0,0,0.5)",
    },
    modalContent: {
      width: "80%",
      maxWidth: 320,
      backgroundColor: theme.background || chatColors.background,
      borderRightWidth: 1,
      borderRightColor: theme.border || chatColors.border,
      elevation: 14,
      shadowColor: "#000",
      shadowOpacity: 0.3,
      shadowRadius: 8,
      shadowOffset: { width: 0, height: 2 },
      justifyContent: "flex-start", // FI9_PATCH v14.2: Menu en haut, pas centré
      paddingTop: 16, // FI9_PATCH v15: Padding top pour menu visible immédiatement en haut
    },
  });

  return (
    <Modal
      visible={visible}
      transparent={true}
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.modalContainer}>
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={onClose}
        />
        <View style={styles.modalContent}>
          <ChatSidebar
            sessions={sessions}
            currentSessionId={currentSessionId}
            activeSessionId={currentSessionId}
            onSelectSession={(sessionId) => {
              onSelectSession(sessionId);
              onClose(); // Fermer le drawer après sélection
            }}
            onNewChat={() => {
              onNewChat();
              onClose(); // Fermer le drawer après nouveau chat
            }}
            onLogout={onLogout}
          />
        </View>
      </View>
    </Modal>
  );
}

