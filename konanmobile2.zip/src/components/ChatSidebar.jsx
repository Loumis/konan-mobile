// FI9_PATCH v14.0 - ChatGPT Mobile 2025 Sidebar
// ChatSidebar.jsx - Menu style ChatGPT avec sections (New Chat, History, Settings, Logout)
// Preserves KONAN structure, style ChatGPT Mobile 2025

import React, { useMemo, useCallback } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  ScrollView,
} from "react-native";
import { useAppTheme } from "../context/AppThemeContext";
import { useLanguage } from "../context/LanguageContext";
import { useAuth } from "../hooks/useAuth";
import { chatColors } from "../constants/colors";

// FI9_PATCH: Try to import lucide-react-native (optional)
let PlusIcon = null;
let MessageSquareIcon = null;
let HistoryIcon = null;
let SettingsIcon = null;
try {
  const lucide = require("lucide-react-native");
  if (lucide) {
    PlusIcon = lucide.Plus;
    MessageSquareIcon = lucide.MessageSquare;
    HistoryIcon = lucide.History;
    SettingsIcon = lucide.Settings;
  }
} catch (e) {
  PlusIcon = null;
  MessageSquareIcon = null;
  HistoryIcon = null;
  SettingsIcon = null;
}

// Try Ionicons for icons
let Ionicons = null;
try {
  const vectorIcons = require("@expo/vector-icons");
  if (vectorIcons && vectorIcons.Ionicons) {
    Ionicons = vectorIcons.Ionicons;
  }
} catch (e) {
  Ionicons = null;
}

export default function ChatSidebar({
  currentSessionId,
  onSelectSession,
  sessions = [],
  activeSessionId,
  onNewChat,
  onLogout,
  onHistory,
  onSettings,
  style,
}) {
  // ============================================
  // HOOKS (ordre fixe, pas de conditions)
  // ============================================
  const { theme } = useAppTheme();
  const { t } = useLanguage();
  const { user } = useAuth();

  const username = useMemo(
    () =>
      user?.name ||
      user?.full_name ||
      user?.username ||
      user?.email?.split("@")[0] ||
      user?.email ||
      "User",
    [user]
  );

  const planLabel = useMemo(() => {
    const planRaw = user?.plan || user?.subscription || "free";
    return planRaw?.toLowerCase() === "legal+"
      ? "Legal+"
      : planRaw?.toLowerCase() === "pro"
      ? "Pro"
      : "Free";
  }, [user]);

  // FI9_PATCH v14.0: Styles ChatGPT Mobile 2025
  const styles = useMemo(
    () =>
      StyleSheet.create({
        sidebar: {
          flex: 1,
          backgroundColor: theme.background || chatColors.background,
        },
        // FI9_PATCH v14.0: Header style ChatGPT "KONAN • [Plan]"
        header: {
          paddingHorizontal: 20,
          paddingVertical: 20,
          borderBottomWidth: 1,
          borderBottomColor: theme.border || chatColors.border,
          backgroundColor: theme.background || chatColors.background,
        },
        headerTitle: {
          fontSize: 22,
          fontWeight: "700",
          color: theme.text || chatColors.textPrimary,
        },
        headerPlan: {
          fontSize: 16,
          fontWeight: "400",
          color: theme.textMuted || chatColors.textSecondary,
          marginTop: 4,
        },
        // FI9_PATCH v14.0: Menu flottant style ChatGPT
        menuSection: {
          paddingHorizontal: 16,
          paddingVertical: 12,
          alignSelf: "stretch",
        },
        menuItem: {
          flexDirection: "row",
          alignItems: "center",
          paddingVertical: 12,
          paddingHorizontal: 12,
          borderRadius: 12,
          alignSelf: "stretch",
          marginHorizontal: 16,
          marginBottom: 4,
        },
        menuItemActive: {
          backgroundColor: theme.surface || chatColors.surface,
        },
        menuIcon: {
          width: 32,
          height: 32,
          borderRadius: 8,
          backgroundColor: theme.surface || chatColors.surface,
          alignItems: "center",
          justifyContent: "center",
          marginRight: 12,
        },
        menuText: {
          fontSize: 16,
          fontWeight: "500",
          color: theme.text || chatColors.textPrimary,
        },
        // Sessions list
        sessionsHeader: {
          paddingHorizontal: 20,
          paddingVertical: 12,
          borderTopWidth: 1,
          borderTopColor: theme.border || chatColors.border,
          borderBottomWidth: 1,
          borderBottomColor: theme.border || chatColors.border,
          backgroundColor: theme.surface || chatColors.surface,
        },
        sessionsHeaderText: {
          fontSize: 14,
          fontWeight: "600",
          color: theme.textMuted || chatColors.textSecondary,
          textTransform: "uppercase",
          letterSpacing: 0.5,
        },
        listContainer: {
          paddingHorizontal: 8,
          paddingBottom: 8,
        },
        sessionItem: {
          paddingHorizontal: 12,
          paddingVertical: 12,
          borderRadius: 10,
          marginHorizontal: 8,
          marginVertical: 4,
          flexDirection: "row",
          alignItems: "center",
          gap: 12,
        },
        sessionItemActive: {
          backgroundColor: theme.surface || chatColors.sidebarActive,
        },
        sessionIcon: {
          width: 40,
          height: 40,
          borderRadius: 20,
          backgroundColor: theme.surface || chatColors.surface,
          alignItems: "center",
          justifyContent: "center",
        },
        sessionContent: {
          flex: 1,
        },
        sessionTitle: {
          fontSize: 16,
          fontWeight: "600",
          color: theme.text || chatColors.textPrimary,
          marginBottom: 2,
        },
        sessionTitleActive: {
          color: theme.primary || chatColors.accent,
        },
        sessionSubtitle: {
          fontSize: 13,
          color: theme.textMuted || chatColors.textSecondary,
        },
        emptyContainer: {
          paddingHorizontal: 16,
          paddingVertical: 16,
        },
        emptyText: {
          color: theme.textMuted || chatColors.textSecondary,
          fontSize: 14,
        },
        // Footer user info
        footer: {
          paddingHorizontal: 16,
          paddingVertical: 12,
          borderTopWidth: 1,
          borderTopColor: theme.border || chatColors.border,
          backgroundColor: theme.surface || chatColors.surface,
        },
        footerUser: {
          flexDirection: "row",
          alignItems: "center",
        },
        footerUsername: {
          fontSize: 14,
          fontWeight: "600",
          color: theme.text || chatColors.textPrimary,
        },
        footerPlan: {
          fontSize: 12,
          color: theme.textMuted || chatColors.textSecondary,
        },
        versionInfo: {
          paddingHorizontal: 16,
          paddingVertical: 8,
          borderTopWidth: 1,
          borderTopColor: theme.border || chatColors.border,
        },
        versionText: {
          fontSize: 11,
          color: theme.textMuted || chatColors.textSecondary,
          textAlign: "center",
        },
      }),
    [theme]
  );

  // Rendu d'un item de session (mémorisé)
  const renderItem = useCallback(
    ({ item }) => {
      const isActive = item.id === (activeSessionId || currentSessionId);
      return (
        <TouchableOpacity
          style={[styles.sessionItem, isActive && styles.sessionItemActive]}
          onPress={() => onSelectSession?.(item.id)}
          activeOpacity={0.8}
        >
          <View style={styles.sessionIcon}>
            {MessageSquareIcon ? (
              <MessageSquareIcon
                size={20}
                color={
                  isActive
                    ? theme.primary || chatColors.accent
                    : theme.textMuted || chatColors.textMuted
                }
                strokeWidth={2}
              />
            ) : Ionicons ? (
              <Ionicons
                name="chatbubbles-outline"
                size={20}
                color={
                  isActive
                    ? theme.primary || chatColors.accent
                    : theme.textMuted || chatColors.textMuted
                }
              />
            ) : (
              <Text style={{ fontSize: 16 }}>💬</Text>
            )}
          </View>
          <View style={styles.sessionContent}>
            <Text
              style={[styles.sessionTitle, isActive && styles.sessionTitleActive]}
              numberOfLines={1}
            >
              {item.title || t("newChat") || "New Chat"}
            </Text>
            {item.lastMessage ? (
              <Text style={styles.sessionSubtitle} numberOfLines={1}>
                {item.lastMessage}
              </Text>
            ) : (
              <Text style={styles.sessionSubtitle} numberOfLines={1}>
                {t("emptyChat") || "Empty chat"}
              </Text>
            )}
          </View>
        </TouchableOpacity>
      );
    },
    [activeSessionId, currentSessionId, styles, theme, t, onSelectSession]
  );

  const keyExtractor = useCallback((item) => item.id, []);

  const renderEmpty = useCallback(
    () => (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>
          {t("noSessions") || "No conversations yet"}
        </Text>
      </View>
    ),
    [styles, t]
  );

  return (
    <View style={[styles.sidebar, style]}>
      <ScrollView
        style={{ flex: 1 }}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingTop: 20,
          paddingBottom: 20,
          flexGrow: 1, // FI9_PATCH v15: Éviter le centrage vertical
        }}
      >
        {/* FI9_PATCH v14.0: Header "KONAN • [Plan]" */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>KONAN</Text>
          <Text style={styles.headerPlan}>• {planLabel}</Text>
        </View>

        {/* FI9_PATCH v14.0: Menu flottant style ChatGPT */}
        <View style={styles.menuSection}>
          {/* New Chat */}
          <TouchableOpacity
            style={[styles.menuItem, styles.menuItemActive]}
            onPress={onNewChat}
            activeOpacity={0.8}
          >
            <View style={styles.menuIcon}>
              {PlusIcon ? (
                <PlusIcon
                  size={18}
                  color={theme.primary || chatColors.accent}
                  strokeWidth={2.5}
                />
              ) : Ionicons ? (
                <Ionicons
                  name="add"
                  size={18}
                  color={theme.primary || chatColors.accent}
                />
              ) : (
                <Text style={{ fontSize: 16 }}>+</Text>
              )}
            </View>
            <Text style={styles.menuText}>
              {t("newChat") || "New Chat"}
            </Text>
          </TouchableOpacity>

          {/* History */}
          {onHistory && (
            <TouchableOpacity
              style={styles.menuItem}
              onPress={onHistory}
              activeOpacity={0.8}
            >
              <View style={styles.menuIcon}>
                {HistoryIcon ? (
                  <HistoryIcon
                    size={18}
                    color={theme.text || chatColors.textPrimary}
                    strokeWidth={2}
                  />
                ) : Ionicons ? (
                  <Ionicons
                    name="time-outline"
                    size={18}
                    color={theme.text || chatColors.textPrimary}
                  />
                ) : (
                  <Text style={{ fontSize: 16 }}>🕐</Text>
                )}
              </View>
              <Text style={styles.menuText}>
                {t("history") || "History"}
              </Text>
            </TouchableOpacity>
          )}

          {/* Settings */}
          {onSettings && (
            <TouchableOpacity
              style={styles.menuItem}
              onPress={onSettings}
              activeOpacity={0.8}
            >
              <View style={styles.menuIcon}>
                {SettingsIcon ? (
                  <SettingsIcon
                    size={18}
                    color={theme.text || chatColors.textPrimary}
                    strokeWidth={2}
                  />
                ) : Ionicons ? (
                  <Ionicons
                    name="settings-outline"
                    size={18}
                    color={theme.text || chatColors.textPrimary}
                  />
                ) : (
                  <Text style={{ fontSize: 16 }}>⚙️</Text>
                )}
              </View>
              <Text style={styles.menuText}>
                {t("settings") || "Settings"}
              </Text>
            </TouchableOpacity>
          )}

          {/* Logout */}
          {onLogout && (
            <TouchableOpacity
              style={styles.menuItem}
              onPress={onLogout}
              activeOpacity={0.8}
            >
              <View style={styles.menuIcon}>
                {Ionicons ? (
                  <Ionicons
                    name="log-out-outline"
                    size={18}
                    color={theme.text || chatColors.textPrimary}
                  />
                ) : (
                  <Text style={{ fontSize: 16 }}>🚪</Text>
                )}
              </View>
              <Text style={styles.menuText}>
                {t("logout") || "Sign Out"}
              </Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Sessions list */}
        {sessions.length > 0 && (
          <>
            <View style={styles.sessionsHeader}>
              <Text style={styles.sessionsHeaderText}>
                {t("history") || "History"}
              </Text>
            </View>
            <FlatList
              data={sessions}
              keyExtractor={keyExtractor}
              renderItem={renderItem}
              contentContainerStyle={styles.listContainer}
              ListEmptyComponent={renderEmpty}
              scrollEnabled={false}
            />
          </>
        )}
      </ScrollView>

      {/* Footer user info */}
      <View style={styles.footer}>
        <View style={styles.footerUser}>
          {Ionicons ? (
            <Ionicons
              name="person-circle-outline"
              size={24}
              color={theme.text || chatColors.textPrimary}
            />
          ) : (
            <Text
              style={{
                fontSize: 20,
                color: theme.text || chatColors.textPrimary,
              }}
            >
              👤
            </Text>
          )}
          <View style={{ marginLeft: 8, flex: 1 }}>
            <Text style={styles.footerUsername} numberOfLines={1}>
              {username}
            </Text>
            <Text style={styles.footerPlan} numberOfLines={1}>
              {planLabel}
            </Text>
          </View>
        </View>
      </View>

      {/* Version info */}
      <View style={styles.versionInfo}>
        <Text style={styles.versionText}>KONAN v14.0</Text>
      </View>
    </View>
  );
}
