// FI9_FIX v20.0 - Enhanced Sidebar Component (Version minimale corrigée)
// Structure simple et stable avec zIndex: 100

import React from "react";
import { View, Text } from "react-native";

export default function EnhancedSidebar() {
  return (
    <View
      style={{
        position: "absolute",
        left: 0,
        top: 0,
        bottom: 0,
        width: 260,
        backgroundColor: "#111",
        zIndex: 100,
        paddingTop: 40,
      }}
    >
      <Text style={{ color: "#fff", padding: 16 }}>KONAN</Text>
    </View>
  );
}
