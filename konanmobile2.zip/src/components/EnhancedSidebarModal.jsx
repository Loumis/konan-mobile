// FI9_UI_UPGRADE v15.0 - Enhanced Sidebar Modal Component
// Modal drawer for mobile using EnhancedSidebar
// Preserves all existing KONAN logic - UI only upgrade

import React from "react";
import { View, StyleSheet, Modal, TouchableOpacity, Platform } from "react-native";
import { useAppTheme } from "../context/AppThemeContext";
import { chatColors } from "../constants/colors";
import EnhancedSidebar from "./EnhancedSidebar";

export default function EnhancedSidebarModal({
  visible,
  onClose,
  sessions,
  currentSessionId,
  onSelectSession,
  onNewChat,
  onLogout,
  onHistory,
  onSettings,
  onGPTs,
  onTools,
  onMarketplace,
  user,
  enableUserMenu = true,
  onNavigateToSubscription,
}) {
  const { theme } = useAppTheme();

  const styles = StyleSheet.create({
    modalContainer: {
      flex: 1,
      flexDirection: "row",
    },
    modalOverlay: {
      flex: 1,
      backgroundColor: "rgba(0,0,0,0.5)",
    },
    modalContent: {
      width: "80%",
      maxWidth: 320,
      backgroundColor: theme.background || chatColors.background,
      borderRightWidth: 1,
      borderRightColor: theme.border || chatColors.border,
      elevation: 14,
      shadowColor: "#000",
      shadowOpacity: 0.3,
      shadowRadius: 8,
      shadowOffset: { width: 0, height: 2 },
      justifyContent: "flex-start",
      paddingTop: 16,
    },
  });

  return (
    <Modal
      visible={visible}
      transparent={true}
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.modalContainer}>
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={onClose}
        />
        <View style={styles.modalContent}>
          <EnhancedSidebar
            currentSessionId={currentSessionId}
            activeSessionId={currentSessionId}
            sessions={sessions}
            onSelectSession={onSelectSession}
            onNewChat={onNewChat}
            onLogout={onLogout}
            onHistory={onHistory}
            onSettings={onSettings}
            onGPTs={onGPTs}
            onTools={onTools}
            onMarketplace={onMarketplace}
            visible={visible}
            enableUserMenu={enableUserMenu}
            onNavigateToSubscription={onNavigateToSubscription}
          />
        </View>
      </View>
    </Modal>
  );
}

