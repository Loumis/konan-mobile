/**
 * FI9_NAYEK: Component exports
 * LEGACY_FI9: ChatBubble, Sidebar, TypingIndicator déplacés vers legacy_ui
 */
export { Avatar } from './Avatar';
// LEGACY_FI9: ChatBubble déplacé vers legacy_ui/components/ChatBubble.tsx
// export { ChatBubble, type Message } from './ChatBubble';
export { Header } from './Header';
// LEGACY_FI9: Sidebar déplacé vers legacy_ui/components/Sidebar.tsx
// export { Sidebar, type Conversation } from './Sidebar';
export { StatusIndicator } from './StatusIndicator';
// LEGACY_FI9: TypingIndicator déplacé vers legacy_ui/components/TypingIndicator.tsx
// export { TypingIndicator } from './TypingIndicator';
export { MessageCompressor } from './MessageCompressor';

