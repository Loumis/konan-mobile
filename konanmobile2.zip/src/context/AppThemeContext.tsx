// FI9_NAYEK v13: App Theme Context (Light/Dark/Auto)
// TODO: REMOVE BEFORE PROD - Runtime path verifier
console.log("[FI9_RUNTIME] Loaded:", "src/context/AppThemeContext.tsx");
import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useColorScheme } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

export type ThemeMode = "light" | "dark" | "auto";

const THEME_KEY = "KONAN_THEME";
const DEFAULT_THEME: ThemeMode = "dark";

interface ThemeColors {
  background: string;
  surface: string;
  text: string;
  textMuted: string;
  border: string;
  primary: string;
}

const lightTheme: ThemeColors = {
  background: "#FFFFFF",
  surface: "#F5F5F5",
  text: "#1f1f1f",
  textMuted: "rgba(31,31,31,0.6)",
  border: "rgba(31,31,31,0.1)",
  primary: "#10A37F",
};

const darkTheme: ThemeColors = {
  background: "#0B0B0B",
  surface: "#1f1f1f",
  text: "#FFFFFF",
  textMuted: "rgba(255,255,255,0.6)",
  border: "rgba(255,255,255,0.1)",
  primary: "#10A37F",
};

interface AppThemeContextValue {
  theme: ThemeColors;
  mode: ThemeMode;
  setMode: (mode: ThemeMode) => Promise<void>;
  isDark: boolean;
}

const AppThemeContext = createContext<AppThemeContextValue | undefined>(undefined);

export function useAppTheme() {
  const context = useContext(AppThemeContext);
  if (!context) {
    throw new Error("useAppTheme must be used within AppThemeProvider");
  }
  return context;
}

interface AppThemeProviderProps {
  children: ReactNode;
}

export function AppThemeProvider({ children }: AppThemeProviderProps) {
  // TODO: REMOVE BEFORE PROD - Runtime path verifier
  console.log("[FI9_RUNTIME] Render:", "src/context/AppThemeContext.tsx");
  const [mode, setModeState] = useState<ThemeMode>(DEFAULT_THEME);
  const [loading, setLoading] = useState(true);
  const systemColorScheme = useColorScheme();

  // Load theme from storage on mount
  useEffect(() => {
    loadTheme();
  }, []);

  const loadTheme = async () => {
    try {
      const saved = await AsyncStorage.getItem(THEME_KEY);
      if (saved && (saved === "light" || saved === "dark" || saved === "auto")) {
        setModeState(saved as ThemeMode);
      }
    } catch (error) {
      console.error("[FI9] Error loading theme:", error);
    } finally {
      setLoading(false);
    }
  };

  const setMode = async (newMode: ThemeMode) => {
    try {
      await AsyncStorage.setItem(THEME_KEY, newMode);
      setModeState(newMode);
      console.log(`[FI9] Theme changed to: ${newMode}`);
    } catch (error) {
      console.error("[FI9] Error saving theme:", error);
    }
  };

  // Determine actual theme based on mode
  const getEffectiveTheme = (): ThemeColors => {
    if (mode === "auto") {
      // Auto: follow system or time-based (20h → dark, 07h → light)
      const hour = new Date().getHours();
      const isSystemDark = systemColorScheme === "dark";
      const isTimeDark = hour >= 20 || hour < 7;
      return (isSystemDark || isTimeDark) ? darkTheme : lightTheme;
    }
    return mode === "dark" ? darkTheme : lightTheme;
  };

  const effectiveTheme = getEffectiveTheme();
  // FI9_NAYEK v14: Mémoriser isDark pour éviter recalculs inutiles
  const isDark = React.useMemo(() => {
    if (mode === "dark") return true;
    if (mode === "light") return false;
    // Auto mode: follow system or time-based
    const hour = new Date().getHours();
    return systemColorScheme === "dark" || hour >= 20 || hour < 7;
  }, [mode, systemColorScheme]);

  if (loading) {
    return null;
  }

  return (
    <AppThemeContext.Provider
      value={{
        theme: effectiveTheme,
        mode,
        setMode,
        isDark,
      }}
    >
      {children}
    </AppThemeContext.Provider>
  );
}

