// FI9_NAYEK: Configuration Expo unifiée avec EXPO_PUBLIC_API_URL
import 'dotenv/config';
import type { ExpoConfig } from 'expo/config';

// FI9_NAYEK: Priorité inversée - API_BASE_URL AVANT VITE_API_BASE_URL
// Suppression de toute résolution vers localhost
const getAPIUrl = (): string => {
  const raw =
    process.env.EXPO_PUBLIC_API_URL ||
    process.env.API_BASE_URL ||
    process.env.VITE_API_BASE_URL ||
    'http://192.168.0.184:8000';
  
  // Remplacer localhost/127.0.0.1 par IP LAN
  if (raw.includes('localhost') || raw.includes('127.0.0.1')) {
    return 'http://192.168.0.184:8000';
  }
  
  return raw;
};

const API_URL = getAPIUrl();

const config: ExpoConfig = {
  name: 'Konanmobile2',
  slug: 'konanmobile2',
  version: '1.0.0',
  sdkVersion: '54.0.0',
  extra: {
    API_URL, // FI9_NAYEK: Utilisation de API_URL unifié
    API_BASE_URL: API_URL, // Compatibilité avec le code existant
  },
  experiments: {
    tsconfigPaths: true,
  },
  android: {
    package: "com.anonymous.konanmobile2", // FI9: Package name for Android
    softwareKeyboardLayoutMode: "resize", // FI9: FIX KEYBOARD - Force resize mode
    windowSoftInputMode: "adjustResize", // FI9: FIX KEYBOARD - Force adjustResize
    usesCleartextTraffic: true, // FI9: HTTP support
  },
};

export default config;
